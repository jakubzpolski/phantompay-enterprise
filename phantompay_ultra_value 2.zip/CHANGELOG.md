# Changelog

## v2.0.0 - Enterprise Edition
- Added professional pitch deck (PDF)
- Added CI/CD pipeline with GitHub Actions
- Added detailed API blueprint
- Added analytics stubs and logging utilities
- Added admin dashboard scaffolding
- Added automated test examples

## v1.0.0 - Pro+
- Initial release with FastAPI + React + Docker + Stripe integration
