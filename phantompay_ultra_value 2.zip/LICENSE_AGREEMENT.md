# PhantomPay Enterprise License Agreement

This license grants the buyer:
- Full access to source code
- Rights to customize and deploy
- Rights to resell with white-label branding

Restrictions:
- Cannot relicense as open source without permission
- Cannot remove "Powered by PhantomPay" branding unless agreed in writing
