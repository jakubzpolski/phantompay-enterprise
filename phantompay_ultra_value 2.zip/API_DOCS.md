# PhantomPay API Blueprint

## Health Check
**GET** `/api/health`
Returns system status.

## Create Payment Request
**POST** `/api/create-request`
Request:
```json
{
  "amount": 5000,
  "currency": "usd"
}
```
Response:
```json
{
  "hash_id": "abc123",
  "status": "pending"
}
```

## Create Checkout Session
**POST** `/api/checkout/{hash_id}`
Returns Stripe Checkout URL.

## Get Payment Status
**GET** `/api/status/{hash_id}`
Returns current status of the payment request.

## Stripe Webhook
**POST** `/webhook/stripe`
Handles payment success events.
