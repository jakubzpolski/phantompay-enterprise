# Deployment Guide

## Local (Docker)
```bash
docker compose up --build
```

## Production (Render + Vercel)
1. Deploy the backend on Render using Dockerfile.
2. Set environment variables for STRIPE and DB.
3. Deploy frontend to Vercel with `VITE_API_URL` pointing to backend URL.

## Scaling
- Use PostgreSQL on RDS or Cloud SQL for high availability.
- Enable HTTPS with custom domains.
