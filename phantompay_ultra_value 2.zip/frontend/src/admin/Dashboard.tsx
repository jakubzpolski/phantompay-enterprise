import React from 'react';

export default function Dashboard(){
  return (
    <div style={{padding:'2rem'}}>
      <h1>Admin Dashboard</h1>
      <p>This is a placeholder for viewing requests, statuses, and Stripe events.</p>
    </div>
  );
}